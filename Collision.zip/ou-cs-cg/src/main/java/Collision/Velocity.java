package Collision;

public class Velocity {
	public int x;
	public int y;
	
	Velocity(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}
